<!DOCTYPE html>
<html>
    <head>
        <title>PHP</title>
<!--        links to css-->
        <link rel="stylesheet" href="">
    </head>
    <body>
    <header style="height: 10vh;color: red;text-align: center">
        <h1>Welcome to my site</h1>
    </header>
    <nav>
        <ul>
            <li>
                <a href="index.php">users/HOME</a>
            </li>
        </ul>
    </nav>
