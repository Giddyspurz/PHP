<!--    links to java script-->
<footer style="height: 30vh;background-color: green">
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus, aliquid animi aut autem beatae consequuntur et explicabo illum, in ipsa laborum natus necessitatibus nihil nobis non, reiciendis saepe sint soluta!</p>
</footer>
</body>
</html>
