<?php
//introduction to php
//PHP is a widely-used, open source scripting language
//PHP scripts are executed on the server
//PHP files can contain text, HTML, CSS, JavaScript, and PHP code
//PHP code is executed on the server,and the result is returned to the browser as
//PHP files have extension ".php"

echo"hello world";
echo"<h1>hello world</h1>";
//echo:print content in browser
//hello world:the content to be printed in the browser
//; :means end of statement or instruction



//VARIABLES IN PHP
//a container for storing data
$myname = "hermit <br>";
echo $myname;
$company = "blueband <br>";
echo $company;
$company2 = "gizmo <br>";
echo $company2;
$company3 = "pasta <br>";

//concatenation/joining
//joining a variable and variable:use the dot operator
echo $company.$company2;
$car1 ="Benz";
$car2 ="Toyota";
//echo $car1.$car2
echo $car1.$car2."<br>";
//joining a string and a variable
echo "I love $car1";


?>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. A maiores obcaecati quibusdam voluptas. A consequuntur impedit quisquam sapiente sunt, voluptatem.</p>